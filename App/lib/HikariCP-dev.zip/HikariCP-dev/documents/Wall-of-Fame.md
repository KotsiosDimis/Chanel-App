<img width="260" valign="middle" src="http://d26gg7w375vuv5.cloudfront.net/Design+Assets/black+Wix+Logo+Assets/Black+Wix+logo+Assets.png">![][spacer]<img width="250" height="88" valign="middle" src="https://www.skytap.com/wp-content/uploads/2016/05/Puppets_company_logo.png">![][spacer]<img width="250" height="88" valign="middle" src="https://web.liferay.com/osb-community-theme/images/custom/heading.png">

<img width="240" valign="middle" src="https://www.playframework.com/assets/images/logos/play_full_color.png">![][spacer]<img width="240" valign="middle" src="https://www.atlassian.com/dam/jcr:416a5a7b-55dc-435d-a3e3-22aa2650ba5d/AtlassianLogo.svg">![][spacer]<img width="240" valign="middle" src="https://www.saydaily.com/.image/c_limit%2Ccs_srgb%2Cq_auto:good%2Cw_410/MTM0ODg3OTkwOTMyNTc1NTA2/screen-shot-2015-12-03-at-22820-pmpng.png">

<img width="240" valign="middle" src="https://upload.wikimedia.org/wikipedia/commons/e/e8/Splunk-Logo.jpg">![][spacer]<img width="240" valign="middle" src="https://www.surpasshosting.com/images/comodo_logo.png">![][spacer]<img width="240" valign="middle" src="https://www.ca.com/content/dam/ca/us/images/company/ca-logo-b-w.jpg">

<img width="260" valign="middle" src="http://fiware-cosmos.readthedocs.io/en/r4_fiware/user_and_programmer_manual/streaming/images/storm_logo.png">![][spacer]<img width="240" valign="middle" src="https://image.slidesharecdn.com/apachehive-151229131013/95/apache-hive-1-638.jpg?cb=1451394627">![][spacer]<img width="240" valign="middle" src="http://design.jboss.org/hibernate/logo/final/hibernate_logo_whitebkg.svg">

<img width="240" valign="middle" src="https://spring.io/img/spring-by-pivotal.png">![][spacer]<img width="240" valign="middle" src="https://jaxenter.com/wp-content/uploads/2013/02/slick.jpg">![][spacer]<img width="240" valign="middle" src="https://www.opennms.com/wp-content/uploads/2015/02/openNMSlogo-transparent-noninterlaced-150ppi.png">

<img width="240" valign="middle" src="https://aries.apache.org/images/Arieslogo_Horizontal.gif">


<img height="60" src="https://github.com/brettwooldridge/HikariCP/wiki/space60x1.gif"/>

-------------------------------------------------------------------------------------
 * Images on this page are Trademarked and Copyrighted by their respective rights holders.
 * Images on this page are used without express permission, and do not constitute an endorsement of HikariCP. If you are a trademark or copyright holder and wish an image to be removed from this page, please open a request in the issue tracker.

[spacer]: https://github.com/brettwooldridge/HikariCP/wiki/space60x1.gif
